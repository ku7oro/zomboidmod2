package com.example.zomboidmod;

import net.minecraft.nbt.NbtCompound;

/** Навыки одного персонажа. */
public class PlayerSkills {
    private static final int N = PzSkill.values().length;

    public int[] level = new int[N];
    public float[] xp = new float[N];      // опыт внутри текущего уровня
    public int[] startLevel = new int[N];  // стартовый уровень (определяет множитель опыта)
    public int profession = 0;
    public boolean chosen = false;
    public long traits = 0L;
    public int[] books = new int[N];        // битовая маска прочитанных томов (1..5)

    public PlayerSkills() {
        apply(Profession.UNEMPLOYED);
        chosen = false;
    }

    public void apply(Profession p) {
        apply(p, 0L);
    }

    /** Профессия + черты: стартовые уровни складываются, Сила и Форма от 5. */
    public void apply(Profession p, long traitMask) {
        profession = p.ordinal();
        traits = traitMask;
        for (PzSkill s : PzSkill.values()) {
            int lv = p.start(s);
            for (PzTrait t : PzTrait.values()) {
                if (PzTrait.has(traitMask, t)) lv += t.skills.getOrDefault(s, 0);
            }
            lv = Math.max(0, Math.min(10, lv));
            level[s.ordinal()] = lv;
            startLevel[s.ordinal()] = lv;
            xp[s.ordinal()] = 0;
        }
        chosen = true;
    }

    /** Множитель опыта по стартовому уровню, как в PZ: 0 -> x1, 1 -> x3, 2 -> x4, 3 и выше -> x5. */
    public int boost(PzSkill s) {
        int st = startLevel[s.ordinal()];
        return st <= 0 ? 1 : (st == 1 ? 3 : (st == 2 ? 4 : 5));
    }

    public NbtCompound toNbt() {
        NbtCompound n = new NbtCompound();
        n.putIntArray("lvl", level);
        n.putIntArray("start", startLevel);
        int[] xi = new int[N];
        for (int i = 0; i < N; i++) xi[i] = Float.floatToIntBits(xp[i]);
        n.putIntArray("xp", xi);
        n.putInt("prof", profession);
        n.putBoolean("chosen", chosen);
        n.putLong("traits", traits);
        n.putIntArray("books", books);
        return n;
    }

    public static PlayerSkills fromNbt(NbtCompound n) {
        PlayerSkills s = new PlayerSkills();
        int[] lvl = n.getIntArray("lvl"), st = n.getIntArray("start"), xi = n.getIntArray("xp");
        for (int i = 0; i < N; i++) {
            if (i < lvl.length) s.level[i] = lvl[i];
            if (i < st.length) s.startLevel[i] = st[i];
            if (i < xi.length) s.xp[i] = Float.intBitsToFloat(xi[i]);
        }
        s.profession = n.getInt("prof");
        s.chosen = n.getBoolean("chosen");
        s.traits = n.getLong("traits");
        int[] bk = n.getIntArray("books");
        for (int i = 0; i < N && i < bk.length; i++) s.books[i] = bk[i];
        return s;
    }
}
