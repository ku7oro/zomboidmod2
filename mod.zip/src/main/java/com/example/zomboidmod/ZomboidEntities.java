package com.example.zomboidmod;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ZomboidEntities {
    public static EntityType<PzZombieEntity> PZ_ZOMBIE;

    private ZomboidEntities() {
    }

    public static void register() {
        PZ_ZOMBIE = Registry.register(Registries.ENTITY_TYPE, Identifier.of(ZomboidMod.MOD_ID, "pz_zombie"),
                EntityType.Builder.create(PzZombieEntity::new, SpawnGroup.MONSTER)
                        .dimensions(0.6f, 1.95f)
                        .maxTrackingRange(8)
                        .build("pz_zombie"));
        FabricDefaultAttributeRegistry.register(PZ_ZOMBIE, ZombieEntity.createZombieAttributes());
    }
}
