package com.example.zomboidmod.block;

import com.example.zomboidmod.world.Loot;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Мебель: поворачивается фасадом к игроку, может быть высокой (2 блока) и иметь инвентарь.
 * Модель смотрит фасадом на север; форма задаётся одной коробкой и поворачивается вместе с блоком.
 */
public class FurnitureBlock extends Block implements BlockEntityProvider {
    public static final DirectionProperty FACING = Properties.HORIZONTAL_FACING;

    public final int rows;          // 0 - без инвентаря, иначе рядов по 9 слотов
    public final boolean tall;      // высотой в 2 блока
    public final Loot loot;         // какой лут кладёт генератор мира
    private final VoxelShape[] shapes = new VoxelShape[4];

    public FurnitureBlock(Settings settings, int rows, boolean tall, Loot loot, double[] box) {
        super(settings);
        this.rows = rows;
        this.tall = tall;
        this.loot = loot;
        for (Direction d : Direction.Type.HORIZONTAL) shapes[d.getHorizontal()] = rotated(box, d);
        setDefaultState(getStateManager().getDefaultState().with(FACING, Direction.NORTH));
    }

    /** Коробка задана для фасада на север; поворачиваем по часовой стрелке. */
    private static VoxelShape rotated(double[] b, Direction d) {
        double x1 = b[0], z1 = b[2], x2 = b[3], z2 = b[5];
        double nx1, nz1, nx2, nz2;
        switch (d) {
            case EAST -> {
                nx1 = 16 - z2; nx2 = 16 - z1; nz1 = x1; nz2 = x2;
            }
            case SOUTH -> {
                nx1 = 16 - x2; nx2 = 16 - x1; nz1 = 16 - z2; nz2 = 16 - z1;
            }
            case WEST -> {
                nx1 = z1; nx2 = z2; nz1 = 16 - x2; nz2 = 16 - x1;
            }
            default -> {
                nx1 = x1; nx2 = x2; nz1 = z1; nz2 = z2;
            }
        }
        return Block.createCuboidShape(nx1, b[1], nz1, nx2, b[4], nz2);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public @Nullable BlockState getPlacementState(ItemPlacementContext ctx) {
        if (tall && !ctx.getWorld().getBlockState(ctx.getBlockPos().up()).canReplace(ctx)) return null;
        return getDefaultState().with(FACING, ctx.getHorizontalPlayerFacing().getOpposite());
    }

    @Override
    public void onPlaced(World world, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.onPlaced(world, pos, state, placer, stack);
        if (tall && !world.isClient) world.setBlockState(pos.up(), ZomboidBlocks.FURNITURE_TOP.getDefaultState(), Block.NOTIFY_ALL);
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return shapes[state.get(FACING).getHorizontal()];
    }

    @Override
    protected BlockState rotate(BlockState state, BlockRotation rotation) {
        return state.with(FACING, rotation.rotate(state.get(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, BlockMirror mirror) {
        return state.rotate(mirror.getRotation(state.get(FACING)));
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (rows <= 0) return ActionResult.PASS;
        if (!world.isClient && world.getBlockEntity(pos) instanceof FurnitureBlockEntity be) player.openHandledScreen(be);
        return ActionResult.success(world.isClient);
    }

    @Override
    protected void onStateReplaced(BlockState state, World world, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.isOf(newState.getBlock())) {
            if (rows > 0) ItemScatterer.onStateReplaced(state, newState, world, pos);
            if (tall && world.getBlockState(pos.up()).isOf(ZomboidBlocks.FURNITURE_TOP)) world.removeBlock(pos.up(), false);
        }
        super.onStateReplaced(state, world, pos, newState, moved);
    }

    @Override
    public @Nullable BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return rows > 0 ? new FurnitureBlockEntity(pos, state) : null;
    }
}
