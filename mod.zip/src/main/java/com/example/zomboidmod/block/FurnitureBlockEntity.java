package com.example.zomboidmod.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventories;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.text.Text;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;

/** Инвентарь мебели (холодильник, шкафы, тумбочки, стеллажи). */
public class FurnitureBlockEntity extends LootableContainerBlockEntity {
    private DefaultedList<ItemStack> items;

    public FurnitureBlockEntity(BlockPos pos, BlockState state) {
        super(ZomboidBlocks.FURNITURE_BE, pos, state);
        int rows = state.getBlock() instanceof FurnitureBlock fb ? Math.max(1, Math.min(3, fb.rows)) : 3;
        items = DefaultedList.ofSize(rows * 9, ItemStack.EMPTY);
    }

    @Override
    protected DefaultedList<ItemStack> getHeldStacks() {
        return items;
    }

    @Override
    protected void setHeldStacks(DefaultedList<ItemStack> list) {
        items = list;
    }

    @Override
    public int size() {
        return items.size();
    }

    @Override
    protected Text getContainerName() {
        return getCachedState().getBlock().getName();
    }

    @Override
    protected ScreenHandler createScreenHandler(int syncId, PlayerInventory inv) {
        int rows = size() / 9;
        ScreenHandlerType<GenericContainerScreenHandler> type = rows == 1 ? ScreenHandlerType.GENERIC_9X1
                : (rows == 2 ? ScreenHandlerType.GENERIC_9X2 : ScreenHandlerType.GENERIC_9X3);
        return new GenericContainerScreenHandler(type, syncId, inv, this, rows);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.readNbt(nbt, lookup);
        items = DefaultedList.ofSize(size(), ItemStack.EMPTY);
        if (!readLootTable(nbt)) Inventories.readNbt(nbt, items, lookup);
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.writeNbt(nbt, lookup);
        if (!writeLootTable(nbt)) Inventories.writeNbt(nbt, items, lookup);
    }
}
