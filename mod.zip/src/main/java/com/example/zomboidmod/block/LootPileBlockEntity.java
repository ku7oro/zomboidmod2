package com.example.zomboidmod.block;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

/** Хранит лежащую вещь и её поворот; синхронизируется с клиентом для отрисовки. */
public class LootPileBlockEntity extends BlockEntity {
    private ItemStack stack = ItemStack.EMPTY;
    private float yaw = 0f;

    public LootPileBlockEntity(BlockPos pos, BlockState state) {
        super(ZomboidBlocks.LOOT_PILE_BE, pos, state);
    }

    public ItemStack stack() {
        return stack;
    }

    public float yaw() {
        return yaw;
    }

    public void set(ItemStack st, float yaw) {
        this.stack = st;
        this.yaw = yaw;
        markDirty();
        if (world != null) world.updateListeners(pos, getCachedState(), getCachedState(), Block.NOTIFY_LISTENERS);
    }

    public ItemStack take() {
        ItemStack s = stack;
        stack = ItemStack.EMPTY;
        markDirty();
        return s;
    }

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.writeNbt(nbt, lookup);
        if (!stack.isEmpty()) nbt.put("item", stack.encode(lookup));
        nbt.putFloat("yaw", yaw);
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        super.readNbt(nbt, lookup);
        stack = nbt.contains("item") ? ItemStack.fromNbt(lookup, nbt.getCompound("item")).orElse(ItemStack.EMPTY) : ItemStack.EMPTY;
        yaw = nbt.getFloat("yaw");
    }

    @Override
    public @Nullable Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }

    @Override
    public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup lookup) {
        return createNbt(lookup);
    }
}
