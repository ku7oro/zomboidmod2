package com.example.zomboidmod.block;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.RotationAxis;

/** Рисует лежащую вещь плашмя. */
public class LootPileRenderer implements BlockEntityRenderer<LootPileBlockEntity> {
    public LootPileRenderer(BlockEntityRendererFactory.Context ctx) {
    }

    @Override
    public void render(LootPileBlockEntity be, float tickDelta, MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        ItemStack st = be.stack();
        if (st.isEmpty()) return;
        m.push();
        m.translate(0.5, 0.03, 0.5);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(be.yaw()));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(90));
        m.scale(0.5f, 0.5f, 0.5f);
        MinecraftClient.getInstance().getItemRenderer().renderItem(st, ModelTransformationMode.FIXED, light, overlay, m, vcp,
                be.getWorld(), (int) be.getPos().asLong());
        m.pop();
    }
}
