package com.example.zomboidmod;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.block.CropBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MaceItem;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Навыки и профессии в духе Project Zomboid: опыт идёт от дела, уровни 0-10. */
public final class Skills {
    /** Опыт за уровень (pzwiki, страница Level): обычные навыки и пассивные (Сила, Форма). */
    private static final int[] XP_REGULAR = {75, 150, 300, 750, 1500, 3000, 4500, 6000, 7500, 9000};
    private static final int[] XP_PASSIVE = {1500, 3000, 6000, 9000, 18000, 30000, 60000, 90000, 120000, 150000};

    /** Общая скорость прокачки (1.0 - как задумано). */
    public static float XP_RATE = 1.0f;

    private static final Identifier MOD_DAMAGE = Identifier.of(ZomboidMod.MOD_ID, "skill_damage");
    private static final Identifier MOD_SPEED = Identifier.of(ZomboidMod.MOD_ID, "skill_attack_speed");
    private static final Identifier MOD_RUN = Identifier.of(ZomboidMod.MOD_ID, "skill_run");
    private static final Identifier MOD_LUCK = Identifier.of(ZomboidMod.MOD_ID, "skill_luck");

    private static final Set<Item> COOKED = Set.of(Items.COOKED_BEEF, Items.COOKED_PORKCHOP, Items.COOKED_CHICKEN,
            Items.COOKED_MUTTON, Items.COOKED_RABBIT, Items.COOKED_COD, Items.COOKED_SALMON, Items.BAKED_POTATO,
            Items.BREAD, Items.PUMPKIN_PIE, Items.MUSHROOM_STEW, Items.RABBIT_STEW, Items.BEETROOT_SOUP,
            Items.SUSPICIOUS_STEW, Items.COOKIE);

    private static final Map<UUID, ItemStack> EATING = new HashMap<>();
    private static final Map<UUID, Integer> EAT_LEFT = new HashMap<>();
    private static final Map<UUID, Integer> FISH = new HashMap<>();
    private static final Map<UUID, Boolean> DIRTY = new HashMap<>();

    private Skills() {
    }

    // ===== данные =====
    public static PlayerSkills of(ServerPlayerEntity p) {
        return SkillState.get(p.getServer()).players.computeIfAbsent(p.getUuid(), k -> new PlayerSkills());
    }

    public static int level(ServerPlayerEntity p, PzSkill s) {
        return of(p).level[s.ordinal()];
    }

    public static int need(PzSkill s, int nextLevel) {
        int[] t = s.passive() ? XP_PASSIVE : XP_REGULAR;
        return t[Math.max(1, Math.min(10, nextLevel)) - 1];
    }

    public static void addXp(ServerPlayerEntity p, PzSkill s, float base) {
        if (p.isCreative() || p.isSpectator()) return;
        PlayerSkills d = of(p);
        int i = s.ordinal();
        if (d.level[i] >= 10) return;
        float mult = 1f;
        if (PzTrait.has(d.traits, PzTrait.FAST_LEARNER)) mult *= 1.3f;
        if (PzTrait.has(d.traits, PzTrait.SLOW_LEARNER)) mult *= 0.7f;
        if (PzTrait.has(d.traits, PzTrait.RELUCTANT_FIGHTER) && (s.category == PzSkill.Category.COMBAT || s == PzSkill.AIMING)) mult *= 0.75f;
        if (PzTrait.has(d.traits, PzTrait.FEAR_OF_BLOOD) && s == PzSkill.FIRST_AID) mult *= 0.5f;
        int vol = d.level[i] / 2 + 1;                       // какой том нужен для текущего уровня
        if ((d.books[i] & (1 << vol)) != 0) mult *= LootItems.SkillBook.MULT[vol - 1];
        d.xp[i] += base * d.boost(s) * XP_RATE * mult;
        while (d.level[i] < 10 && d.xp[i] >= need(s, d.level[i] + 1)) {
            d.xp[i] -= need(s, d.level[i] + 1);
            d.level[i]++;
            p.sendMessage(Text.literal("+ " + s.title + ": уровень " + d.level[i]), true);
        }
        if (d.level[i] >= 10) d.xp[i] = 0;
        SkillState.get(p.getServer()).markDirty();
        DIRTY.put(p.getUuid(), true);
    }

    public static void readBook(ServerPlayerEntity p, PzSkill s, int vol) {
        of(p).books[s.ordinal()] |= 1 << vol;
        SkillState.get(p.getServer()).markDirty();
    }

    public static void setLevel(ServerPlayerEntity p, PzSkill s, int lvl) {
        PlayerSkills d = of(p);
        d.level[s.ordinal()] = Math.max(0, Math.min(10, lvl));
        d.xp[s.ordinal()] = 0;
        SkillState.get(p.getServer()).markDirty();
        sync(p);
    }

    // ===== профессия =====
    public static boolean has(ServerPlayerEntity p, PzTrait t) {
        return PzTrait.has(of(p).traits, t);
    }

    public static void choose(ServerPlayerEntity p, int profession, long traits) {
        PlayerSkills d = of(p);
        if (d.chosen) return; // повторно выбрать нельзя (только после смерти или командой)
        Profession prof = Profession.byIndex(profession);
        if (!PzTrait.valid(prof, traits)) {   // защита от неверного набора черт
            p.sendMessage(Text.literal("Неверный набор черт, выберите ещё раз"), false);
            prompt(p);
            return;
        }
        d.apply(prof, traits);
        SkillState.get(p.getServer()).markDirty();
        p.sendMessage(Text.literal("Профессия: " + prof.title), false);
        sync(p);
    }

    /** Новый персонаж (после смерти, как в PZ): навыки обнуляются, профессия выбирается заново. */
    public static void newCharacter(ServerPlayerEntity p) {
        SkillState st = SkillState.get(p.getServer());
        st.players.put(p.getUuid(), new PlayerSkills());
        st.markDirty();
        EATING.remove(p.getUuid());
        EAT_LEFT.remove(p.getUuid());
        sync(p);
        prompt(p);
    }

    public static void prompt(ServerPlayerEntity p) {
        if (!of(p).chosen) ServerPlayNetworking.send(p, new SkillPayloads.Prompt());
    }

    public static void sync(ServerPlayerEntity p) {
        PlayerSkills d = of(p);
        StringBuilder sb = new StringBuilder().append(d.profession).append(';').append(d.chosen ? 1 : 0).append(';');
        for (PzSkill s : PzSkill.values()) {
            int i = s.ordinal();
            int prog = d.level[i] >= 10 ? 0 : (int) (d.xp[i] * 1000 / need(s, d.level[i] + 1));
            sb.append(d.level[i]).append(':').append(prog).append(':').append(d.boost(s)).append(',');
        }
        sb.append(';').append(d.traits);
        ServerPlayNetworking.send(p, new SkillPayloads.Sync(sb.toString()));
        DIRTY.remove(p.getUuid());
    }

    // ===== оружие и навык боя =====
    public static PzSkill weaponSkill(ItemStack st) {
        Item it = st.getItem();
        if (it == ZomboidMod.BASEBALL_BAT || it == ZomboidMod.SPIKED_BAT || it == ZomboidMod.CROWBAR) return PzSkill.LONG_BLUNT;
        if (it == ZomboidMod.HAMMER || it == ZomboidMod.FRYING_PAN) return PzSkill.SHORT_BLUNT;
        if (it == ZomboidMod.KITCHEN_KNIFE || it == ZomboidMod.HUNTING_KNIFE) return PzSkill.SHORT_BLADE;
        if (it == ZomboidMod.MACHETE) return PzSkill.LONG_BLADE;
        if (it instanceof AxeItem) return PzSkill.AXE;
        if (it instanceof SwordItem) return PzSkill.LONG_BLADE;
        if (it instanceof MaceItem) return PzSkill.SHORT_BLUNT;
        if (it instanceof ShovelItem || it instanceof PickaxeItem || it instanceof HoeItem) return PzSkill.LONG_BLUNT;
        return null;
    }

    private static void setMod(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr, Identifier id, double value) {
        EntityAttributeInstance inst = p.getAttributeInstance(attr);
        if (inst == null) return;
        EntityAttributeModifier cur = inst.getModifier(id);
        if (cur != null && Math.abs(cur.value() - value) < 1e-6) return;
        inst.removeModifier(id);
        if (Math.abs(value) > 1e-6) {
            inst.addTemporaryModifier(new EntityAttributeModifier(id, value, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        }
    }

    /** Каждые 5 тиков: бонусы к урону, скорости атаки, бегу и удаче от навыков. */
    public static void applyModifiers(ServerPlayerEntity p) {
        PlayerSkills d = of(p);
        PzSkill ws = weaponSkill(p.getMainHandStack());
        int str = d.level[PzSkill.STRENGTH.ordinal()];
        double dmg = (str - 5) * 0.04;                         // сила: +-4% за уровень от 5
        double spd = 0;
        if (ws != null) {
            int wl = d.level[ws.ordinal()];
            dmg += wl * 0.05;                                  // навык оружия: +5% урона за уровень
            spd = wl * 0.02;                                   // и +2% скорости атаки
        }
        setMod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, MOD_DAMAGE, dmg);
        setMod(p, EntityAttributes.GENERIC_ATTACK_SPEED, MOD_SPEED, spd);
        double run = p.isSprinting() ? d.level[PzSkill.SPRINTING.ordinal()] * 0.015 : 0;  // бег: +1.5% скорости за уровень
        setMod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, MOD_RUN, run);
        EntityAttributeInstance luck = p.getAttributeInstance(EntityAttributes.GENERIC_LUCK);
        if (luck != null) {
            luck.removeModifier(MOD_LUCK);
            int f = d.level[PzSkill.FISHING.ordinal()];
            if (f > 0) luck.addTemporaryModifier(new EntityAttributeModifier(MOD_LUCK, f * 0.3,
                    EntityAttributeModifier.Operation.ADD_VALUE));
        }
    }

    // ===== опыт от дела =====
    /** Каждый тик: еда (кулинария) и бонусы. */
    public static void tick(ServerPlayerEntity p, int serverTicks) {
        if (serverTicks % 5 == 0) applyModifiers(p);

        UUID id = p.getUuid();
        ItemStack active = p.isUsingItem() ? p.getActiveItem() : ItemStack.EMPTY;
        if (!active.isEmpty() && active.get(DataComponentTypes.FOOD) != null) {
            EATING.put(id, active.copyWithCount(1));
            EAT_LEFT.put(id, p.getItemUseTimeLeft());
        } else if (EATING.containsKey(id)) {
            ItemStack food = EATING.remove(id);
            Integer left = EAT_LEFT.remove(id);
            if (left != null && left <= 1 && COOKED.contains(food.getItem())) {
                int lv = level(p, PzSkill.COOKING);
                if (lv > 0) p.getHungerManager().add(lv >= 5 ? 1 : 0, 0.4f * lv);  // умелый повар - сытнее еда
                addXp(p, PzSkill.COOKING, 6);
            }
        }
    }

    /** Раз в секунду: пассивный опыт (бег, ходьба, скрытность, рыбалка). */
    public static void second(ServerPlayerEntity p) {
        double v = p.getVelocity().horizontalLength();
        boolean moving = v > 0.05;
        if (p.isSprinting()) {
            addXp(p, PzSkill.SPRINTING, 1.5f);
            addXp(p, PzSkill.FITNESS, 2f);
        } else if (p.isSwimming() || (p.isTouchingWater() && moving)) {
            addXp(p, PzSkill.FITNESS, 2f);
        } else if (moving) {
            addXp(p, PzSkill.LIGHTFOOTED, p.isSneaking() ? 0.8f : 0.3f);
        }

        // скрытность и проворство рядом с зомби
        List<PzZombieEntity> near = p.getWorld().getEntitiesByClass(PzZombieEntity.class,
                p.getBoundingBox().expand(12), Entity::isAlive);
        if (!near.isEmpty()) {
            boolean hunted = false, close = false;
            for (PzZombieEntity z : near) {
                if (z.getTarget() == p) hunted = true;
                if (z.squaredDistanceTo(p) < 16) close = true;
            }
            if (p.isSneaking() && moving && !hunted) addXp(p, PzSkill.SNEAKING, 2.5f);
            if (hunted && close && moving) addXp(p, PzSkill.NIMBLE, 1.5f);
        }

        // рыбалка: по статистике пойманной рыбы
        int fish = p.getStatHandler().getStat(Stats.CUSTOM, Stats.FISH_CAUGHT);
        Integer prev = FISH.put(p.getUuid(), fish);
        if (prev != null && fish > prev) addXp(p, PzSkill.FISHING, 15f * (fish - prev));

        if (Boolean.TRUE.equals(DIRTY.get(p.getUuid())) || p.getServer().getTicks() % 100 == 0) sync(p);
    }

    /** Удар в ближнем бою. */
    public static void onMeleeHit(ServerPlayerEntity p, Entity target) {
        if (!(target instanceof LivingEntity) || p.getAttackCooldownProgress(0.5f) < 0.8f) return;
        PzSkill ws = weaponSkill(p.getMainHandStack());
        if (ws != null) addXp(p, ws, 3f);
        addXp(p, PzSkill.STRENGTH, ws != null ? 2f : 1f);
        if (!p.getMainHandStack().isEmpty() && p.getMainHandStack().isDamageable()) addXp(p, PzSkill.MAINTENANCE, 1f);
    }

    /** Убийство: бонусный опыт оружию / меткости. */
    public static void onKill(ServerPlayerEntity p, boolean projectile) {
        if (projectile) {
            addXp(p, PzSkill.AIMING, 8f);
        } else {
            PzSkill ws = weaponSkill(p.getMainHandStack());
            if (ws != null) addXp(p, ws, 10f);
            addXp(p, PzSkill.STRENGTH, 4f);
        }
    }

    public static void onProjectileHit(ServerPlayerEntity p) {
        addXp(p, PzSkill.AIMING, 4f);
    }

    /** Стрела только что выпущена: урон растёт с меткостью (+6% за уровень). */
    public static void onArrowSpawn(PersistentProjectileEntity arrow) {
        if (!(arrow.getOwner() instanceof ServerPlayerEntity p)) return;
        if (arrow.getVelocity().length() < 0.5 || arrow.squaredDistanceTo(p) > 9) return;
        int lv = level(p, PzSkill.AIMING);
        if (lv > 0) arrow.setDamage(arrow.getDamage() * (1 + 0.06 * lv));
    }

    /** Сбор урожая: опыт и шанс лишнего урожая (+8% за уровень). */
    public static void onBlockBreak(ServerPlayerEntity p, ServerWorld world, BlockPos pos, BlockState state) {
        if (state.getBlock() instanceof CropBlock crop && crop.isMature(state)) {
            addXp(p, PzSkill.FARMING, 5f);
            int lv = level(p, PzSkill.FARMING);
            if (lv > 0 && p.getRandom().nextFloat() < lv * 0.08f) {
                List<ItemStack> drops = net.minecraft.block.Block.getDroppedStacks(state, world, pos, null);
                if (!drops.isEmpty()) net.minecraft.block.Block.dropStack(world, pos, drops.get(0).copyWithCount(1));
            }
        } else if (state.getHardness(world, pos) >= 1.5f) {
            addXp(p, PzSkill.STRENGTH, 0.5f);
        }
    }

    /** Уход за оружием: шанс, что удар не отнимет прочность (5% за уровень, до 50%). */
    public static boolean saveDurability(LivingEntity attacker) {
        if (!(attacker instanceof ServerPlayerEntity p)) return false;
        return p.getRandom().nextFloat() < level(p, PzSkill.MAINTENANCE) * 0.05f;
    }

    // ===== эффекты для других систем =====
    /** Первая помощь: повязка дольше остаётся чистой (+15% за уровень, pzwiki). */
    public static float bandageLifeMult(ServerPlayerEntity p) {
        return 1f + 0.15f * level(p, PzSkill.FIRST_AID);
    }

    /** Первая помощь: скорость сращения переломов (уровень 0 - 50%, далее +50% за уровень, pzwiki). */
    public static double fractureMult(ServerPlayerEntity p) {
        return 0.5 + 0.5 * level(p, PzSkill.FIRST_AID);
    }

    /** Лёгкая походка: шаги тише на 6% за уровень. */
    public static double stepNoiseMult(ServerPlayerEntity p) {
        double m = Math.max(0.3, 1.0 - 0.06 * level(p, PzSkill.LIGHTFOOTED));
        if (has(p, PzTrait.GRACEFUL)) m *= 0.8;
        if (has(p, PzTrait.CLUMSY)) m *= 1.25;
        return m;
    }

    /** Скрытность: с какого расстояния зомби замечает крадущегося игрока. */
    public static double sneakDetectRange(ServerPlayerEntity p) {
        double r = Math.max(4.0, 14.0 * (0.8 - 0.05 * level(p, PzSkill.SNEAKING)));
        if (has(p, PzTrait.INCONSPICUOUS)) r *= 0.8;
        if (has(p, PzTrait.CONSPICUOUS)) r *= 1.3;
        return r;
    }

    /** Незаметный: зомби, не атакованный игроком, теряет его дальше этого расстояния (даже если тот не крадётся). */
    public static double inconspicuousRange(ServerPlayerEntity p) {
        return has(p, PzTrait.INCONSPICUOUS) ? 12.0 : 1000.0;
    }

    /** Проворство: шанс вырваться из хватки зомби (7% за уровень). */
    public static boolean escapeGrab(ServerPlayerEntity p) {
        return p.getRandom().nextFloat() < level(p, PzSkill.NIMBLE) * 0.07f;
    }

    /** Физическая форма: множитель восстановления здоровья (+6% за уровень выше 5). */
    public static double fitnessHealMult(ServerPlayerEntity p) {
        return Math.max(0.5, 1.0 + 0.06 * (level(p, PzSkill.FITNESS) - 5));
    }

    /** Быстро / медленно заживает: множитель скорости заживления ран и переломов. */
    public static double healTraitMult(ServerPlayerEntity p) {
        if (has(p, PzTrait.FAST_HEALER)) return 1.6;
        if (has(p, PzTrait.SLOW_HEALER)) return 0.6;
        return 1.0;
    }

    /** Множитель интервала жажды: больше - медленнее хочется пить. */
    public static double thirstIntervalMult(ServerPlayerEntity p) {
        if (has(p, PzTrait.LOW_THIRST)) return 1.5;
        if (has(p, PzTrait.HIGH_THIRST)) return 0.7;
        return 1.0;
    }

    /** Множитель шанса отравиться грязной водой. */
    public static float poisonMult(ServerPlayerEntity p) {
        if (has(p, PzTrait.IRON_GUT)) return 0.5f;
        if (has(p, PzTrait.WEAK_STOMACH)) return 1.5f;
        return 1f;
    }

    /** Множитель срока до смерти от заражения. */
    public static float knoxTimeMult(ServerPlayerEntity p) {
        if (has(p, PzTrait.RESILIENT)) return 1.3f;
        if (has(p, PzTrait.PRONE_TO_ILLNESS)) return 0.75f;
        return 1f;
    }

    /** Раз в секунду: аппетит и заметность. */
    public static void traitSecond(ServerPlayerEntity p) {
        if (has(p, PzTrait.LIGHT_EATER)) p.getHungerManager().addExhaustion(-0.012f);
        if (has(p, PzTrait.HEARTY_APPETITE)) p.getHungerManager().addExhaustion(0.012f);
        if (has(p, PzTrait.CONSPICUOUS) && p.getServer().getTicks() % 100 < 20) Noise.emitFrom(p, 10);
    }

    public static boolean fitForRunning(ServerPlayerEntity p) {
        return level(p, PzSkill.FITNESS) >= 8;
    }

    public static void clear(UUID id) {
        EATING.remove(id);
        EAT_LEFT.remove(id);
        FISH.remove(id);
        DIRTY.remove(id);
    }

    public static void unused(MinecraftServer s) {
    }
}
