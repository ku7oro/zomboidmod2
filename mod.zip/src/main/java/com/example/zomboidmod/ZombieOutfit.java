package com.example.zomboidmod;

import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

/** Одежда зомби (внешний вид + набор вещей в карманах). id совпадает с именем текстуры. */
public enum ZombieOutfit {
    CIVILIAN_TSHIRT("civilian_tshirt", 18, 0),
    CIVILIAN_HOODIE("civilian_hoodie", 10, 0),
    CIVILIAN_JACKET("civilian_jacket", 10, 0),
    CIVILIAN_SHORTS("civilian_shorts", 6, 0),
    BUSINESS("business", 6, 0),
    STUDENT("student", 5, 0),
    TRAILER("trailer", 4, 0),
    MECHANIC("mechanic", 3, 2),
    FARMER("farmer", 4, 0),
    CONSTRUCTION("construction", 4, 2),
    POLICE("police", 4, 4),
    SECURITY("security", 2, 2),
    DOCTOR("doctor", 3, 0),
    NURSE("nurse", 3, 0),
    FIREFIGHTER("firefighter", 2, 4),
    SOLDIER("soldier", 3, 8),
    PRISONER("prisoner", 2, 0),
    BIKER("biker", 3, 2),
    CHEF("chef", 2, 0),
    SURVIVOR("survivor", 2, 2),
    HAZMAT("hazmat", 1, 6),
    PRIEST("priest", 1, 0);

    public final String id;
    public final int weight;
    public final int bonusHealth;

    ZombieOutfit(String id, int weight, int bonusHealth) {
        this.id = id;
        this.weight = weight;
        this.bonusHealth = bonusHealth;
    }

    public static ZombieOutfit random(Random r) {
        int total = 0;
        for (ZombieOutfit o : values()) total += o.weight;
        int n = r.nextInt(total);
        for (ZombieOutfit o : values()) {
            n -= o.weight;
            if (n < 0) return o;
        }
        return CIVILIAN_TSHIRT;
    }

    /** Текстура: тон 0-2 (свежий, бледный, тёмный), для ползуна всегда 3 (оторванные ноги). */
    public static Identifier texture(ZombieOutfit outfit, int tone, ZombieKind kind) {
        int t = kind == ZombieKind.CRAWLER ? 3 : Math.max(0, Math.min(2, tone));
        return Identifier.of(ZomboidMod.MOD_ID, "textures/entity/zombie/pz_" + outfit.id + "_" + t + ".png");
    }
}
